-- MySQL dump 10.14  Distrib 5.5.68-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: piston_logistics
-- ------------------------------------------------------
-- Server version	5.5.68-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ALMACENES`
--

DROP TABLE IF EXISTS `ALMACENES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ALMACENES` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(32) NOT NULL,
  `calle` varchar(64) NOT NULL,
  `numero` varchar(8) NOT NULL,
  `latitud` decimal(10,6) NOT NULL,
  `longitud` decimal(10,6) NOT NULL,
  `baja` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ALMACENES`
--

LOCK TABLES `ALMACENES` WRITE;
/*!40000 ALTER TABLE `ALMACENES` DISABLE KEYS */;
INSERT INTO `ALMACENES` VALUES (1,'Almacén A','Calle 1','1232',40.124560,-74.579200,'\0'),(2,'Almacén B','Calle 2','4561',41.936540,-75.245360,'\0'),(3,'Almacén C','Calle 3','7849',39.533210,-73.865340,'\0'),(4,'Propio A','Calle 4','1333',40.123560,-74.579400,'\0'),(5,'Propio B','Calle 5','4156',41.974540,-75.245336,'\0'),(6,'Propio C','Calle 6','7893',39.545210,-73.864540,'\0');
/*!40000 ALTER TABLE `ALMACENES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ALMACENES_CLIENTES`
--

DROP TABLE IF EXISTS `ALMACENES_CLIENTES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ALMACENES_CLIENTES` (
  `ID` int(11) NOT NULL,
  `RUT` char(12) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `RUT` (`RUT`),
  CONSTRAINT `ALMACENES_CLIENTES_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `ALMACENES` (`ID`),
  CONSTRAINT `ALMACENES_CLIENTES_ibfk_2` FOREIGN KEY (`RUT`) REFERENCES `CLIENTES` (`RUT`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ALMACENES_CLIENTES`
--

LOCK TABLES `ALMACENES_CLIENTES` WRITE;
/*!40000 ALTER TABLE `ALMACENES_CLIENTES` DISABLE KEYS */;
INSERT INTO `ALMACENES_CLIENTES` VALUES (1,'123456789012'),(3,'543216789012'),(2,'987654321098');
/*!40000 ALTER TABLE `ALMACENES_CLIENTES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ALMACENES_PROPIOS`
--

DROP TABLE IF EXISTS `ALMACENES_PROPIOS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ALMACENES_PROPIOS` (
  `ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  CONSTRAINT `ALMACENES_PROPIOS_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `ALMACENES` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ALMACENES_PROPIOS`
--

LOCK TABLES `ALMACENES_PROPIOS` WRITE;
/*!40000 ALTER TABLE `ALMACENES_PROPIOS` DISABLE KEYS */;
INSERT INTO `ALMACENES_PROPIOS` VALUES (4),(5),(6);
/*!40000 ALTER TABLE `ALMACENES_PROPIOS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CAMIONEROS`
--

DROP TABLE IF EXISTS `CAMIONEROS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CAMIONEROS` (
  `CI` char(8) NOT NULL,
  `nombre` varchar(32) NOT NULL,
  `apellido` varchar(32) NOT NULL,
  `baja` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`CI`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CAMIONEROS`
--

LOCK TABLES `CAMIONEROS` WRITE;
/*!40000 ALTER TABLE `CAMIONEROS` DISABLE KEYS */;
INSERT INTO `CAMIONEROS` VALUES ('12345678','Juan','Pérez','\0'),('23456789','Pedro','Sánchez','\0'),('87654321','María','Gómez','\0');
/*!40000 ALTER TABLE `CAMIONEROS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CAMIONES`
--

DROP TABLE IF EXISTS `CAMIONES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CAMIONES` (
  `matricula` char(7) NOT NULL,
  PRIMARY KEY (`matricula`),
  CONSTRAINT `CAMIONES_ibfk_1` FOREIGN KEY (`matricula`) REFERENCES `VEHICULOS` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CAMIONES`
--

LOCK TABLES `CAMIONES` WRITE;
/*!40000 ALTER TABLE `CAMIONES` DISABLE KEYS */;
INSERT INTO `CAMIONES` VALUES ('ABC1234');
/*!40000 ALTER TABLE `CAMIONES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CAMIONETAS`
--

DROP TABLE IF EXISTS `CAMIONETAS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CAMIONETAS` (
  `matricula` char(7) NOT NULL,
  PRIMARY KEY (`matricula`),
  CONSTRAINT `CAMIONETAS_ibfk_1` FOREIGN KEY (`matricula`) REFERENCES `VEHICULOS` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CAMIONETAS`
--

LOCK TABLES `CAMIONETAS` WRITE;
/*!40000 ALTER TABLE `CAMIONETAS` DISABLE KEYS */;
INSERT INTO `CAMIONETAS` VALUES ('DEF9012'),('XYZ5678');
/*!40000 ALTER TABLE `CAMIONETAS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTES`
--

DROP TABLE IF EXISTS `CLIENTES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENTES` (
  `RUT` char(12) NOT NULL,
  `nombre` varchar(32) NOT NULL,
  `baja` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`RUT`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTES`
--

LOCK TABLES `CLIENTES` WRITE;
/*!40000 ALTER TABLE `CLIENTES` DISABLE KEYS */;
INSERT INTO `CLIENTES` VALUES ('123456789012','Cliente 1','\0'),('543216789012','Cliente 3','\0'),('987654321098','Cliente 2','\0');
/*!40000 ALTER TABLE `CLIENTES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONDUCEN`
--

DROP TABLE IF EXISTS `CONDUCEN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CONDUCEN` (
  `CI` char(8) NOT NULL,
  `matricula` char(7) NOT NULL,
  `desde` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hasta` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CI`,`matricula`),
  KEY `matricula` (`matricula`),
  CONSTRAINT `CONDUCEN_ibfk_1` FOREIGN KEY (`CI`) REFERENCES `CAMIONEROS` (`CI`),
  CONSTRAINT `CONDUCEN_ibfk_2` FOREIGN KEY (`matricula`) REFERENCES `VEHICULOS` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONDUCEN`
--

LOCK TABLES `CONDUCEN` WRITE;
/*!40000 ALTER TABLE `CONDUCEN` DISABLE KEYS */;
INSERT INTO `CONDUCEN` VALUES ('12345678','ABC1234','2023-09-13 23:31:37',NULL),('23456789','DEF9012','2023-09-13 23:31:37',NULL),('87654321','XYZ5678','2023-09-13 23:31:37',NULL);
/*!40000 ALTER TABLE `CONDUCEN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DESTINO_LOTE`
--

DROP TABLE IF EXISTS `DESTINO_LOTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DESTINO_LOTE` (
  `ID_lote` int(11) NOT NULL,
  `ID_almacen` int(11) NOT NULL,
  `ID_troncal` int(11) NOT NULL,
  PRIMARY KEY (`ID_lote`),
  KEY `ID_almacen` (`ID_almacen`,`ID_troncal`),
  CONSTRAINT `DESTINO_LOTE_ibfk_1` FOREIGN KEY (`ID_lote`) REFERENCES `LOTES` (`ID`),
  CONSTRAINT `DESTINO_LOTE_ibfk_2` FOREIGN KEY (`ID_almacen`, `ID_troncal`) REFERENCES `ORDENES` (`ID_almacen`, `ID_troncal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DESTINO_LOTE`
--

LOCK TABLES `DESTINO_LOTE` WRITE;
/*!40000 ALTER TABLE `DESTINO_LOTE` DISABLE KEYS */;
INSERT INTO `DESTINO_LOTE` VALUES (2,4,1),(3,5,1),(1,6,1);
/*!40000 ALTER TABLE `DESTINO_LOTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ESTADOS`
--

DROP TABLE IF EXISTS `ESTADOS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ESTADOS` (
  `ID_lote` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tipo` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID_lote`,`fecha`),
  CONSTRAINT `ESTADOS_ibfk_1` FOREIGN KEY (`ID_lote`) REFERENCES `LOTES` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ESTADOS`
--

LOCK TABLES `ESTADOS` WRITE;
/*!40000 ALTER TABLE `ESTADOS` DISABLE KEYS */;
INSERT INTO `ESTADOS` VALUES (1,'2023-09-13 23:31:38',0),(2,'2023-09-13 23:31:38',1),(3,'2023-09-13 23:31:38',2);
/*!40000 ALTER TABLE `ESTADOS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LLEVA`
--

DROP TABLE IF EXISTS `LLEVA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LLEVA` (
  `ID_lote` int(11) NOT NULL,
  `matricula` char(7) DEFAULT NULL,
  `fecha_carga` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_descarga` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID_lote`),
  KEY `matricula` (`matricula`),
  CONSTRAINT `LLEVA_ibfk_1` FOREIGN KEY (`ID_lote`) REFERENCES `LOTES` (`ID`),
  CONSTRAINT `LLEVA_ibfk_2` FOREIGN KEY (`matricula`) REFERENCES `CAMIONES` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LLEVA`
--

LOCK TABLES `LLEVA` WRITE;
/*!40000 ALTER TABLE `LLEVA` DISABLE KEYS */;
INSERT INTO `LLEVA` VALUES (1,'ABC1234','2023-09-13 23:31:38',NULL),(2,'ABC1234','2023-09-13 23:31:38',NULL),(3,'ABC1234','2023-09-13 23:31:38',NULL);
/*!40000 ALTER TABLE `LLEVA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOTES`
--

DROP TABLE IF EXISTS `LOTES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LOTES` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_troncal` int(11) NOT NULL,
  `ID_almacen` int(11) NOT NULL,
  `tipo` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`ID`),
  KEY `ID_almacen` (`ID_almacen`),
  KEY `ID_troncal` (`ID_troncal`),
  CONSTRAINT `LOTES_ibfk_1` FOREIGN KEY (`ID_almacen`) REFERENCES `ORDENES` (`ID_almacen`),
  CONSTRAINT `LOTES_ibfk_2` FOREIGN KEY (`ID_troncal`) REFERENCES `ORDENES` (`ID_troncal`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOTES`
--

LOCK TABLES `LOTES` WRITE;
/*!40000 ALTER TABLE `LOTES` DISABLE KEYS */;
INSERT INTO `LOTES` VALUES (1,1,4,'\0'),(2,1,5,''),(3,1,6,'\0');
/*!40000 ALTER TABLE `LOTES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDENES`
--

DROP TABLE IF EXISTS `ORDENES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ORDENES` (
  `ID_almacen` int(11) NOT NULL,
  `ID_troncal` int(11) NOT NULL,
  `orden` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`ID_almacen`,`ID_troncal`),
  KEY `ID_troncal` (`ID_troncal`),
  CONSTRAINT `ORDENES_ibfk_1` FOREIGN KEY (`ID_almacen`) REFERENCES `ALMACENES_PROPIOS` (`ID`),
  CONSTRAINT `ORDENES_ibfk_2` FOREIGN KEY (`ID_troncal`) REFERENCES `TRONCALES` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDENES`
--

LOCK TABLES `ORDENES` WRITE;
/*!40000 ALTER TABLE `ORDENES` DISABLE KEYS */;
INSERT INTO `ORDENES` VALUES (4,1,1),(5,1,1),(6,1,1);
/*!40000 ALTER TABLE `ORDENES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PAQUETES`
--

DROP TABLE IF EXISTS `PAQUETES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PAQUETES` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_almacen` int(11) NOT NULL,
  `fecha_registrado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ID_pickup` int(11) NOT NULL,
  `calle` varchar(32) DEFAULT NULL,
  `numero` varchar(8) DEFAULT NULL,
  `ciudad` varchar(32) DEFAULT NULL,
  `peso` int(10) unsigned DEFAULT NULL,
  `volumen` int(10) unsigned DEFAULT NULL,
  `fecha_recibido` timestamp NULL DEFAULT NULL,
  `mail` varchar(64) DEFAULT NULL,
  `cedula` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_almacen` (`ID_almacen`),
  KEY `ID_pickup` (`ID_pickup`),
  CONSTRAINT `PAQUETES_ibfk_1` FOREIGN KEY (`ID_almacen`) REFERENCES `ALMACENES_CLIENTES` (`ID`),
  CONSTRAINT `PAQUETES_ibfk_2` FOREIGN KEY (`ID_pickup`) REFERENCES `ALMACENES_PROPIOS` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PAQUETES`
--

LOCK TABLES `PAQUETES` WRITE;
/*!40000 ALTER TABLE `PAQUETES` DISABLE KEYS */;
INSERT INTO `PAQUETES` VALUES (1,1,'2023-09-13 23:31:38',4,'calle','1010','rivera',5,10,NULL,'cliente1@mail.com','12345678'),(2,2,'2023-09-13 23:31:38',5,'calle','1010','canelones',8,15,NULL,'cliente2@mail.com','87654321'),(3,2,'2023-09-13 23:31:38',5,'calle','1010','melo',8,15,NULL,'cliente2@mail.com','87654321'),(4,3,'2023-09-13 23:31:38',6,'calle','1010','meontevideo',6,12,NULL,'cliente3@mail.com','23456789'),(5,3,'2023-09-13 23:31:38',6,'calle','1010','montevideo',6,12,NULL,'cliente3@mail.com','23456789'),(6,3,'2023-09-13 23:31:38',6,'calle','1010','melo',6,12,NULL,'cliente3@mail.com','23456789');
/*!40000 ALTER TABLE `PAQUETES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PAQUETES_LOTES`
--

DROP TABLE IF EXISTS `PAQUETES_LOTES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PAQUETES_LOTES` (
  `ID_paquete` int(11) NOT NULL,
  `ID_lote` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID_paquete`,`ID_lote`),
  KEY `ID_lote` (`ID_lote`),
  CONSTRAINT `PAQUETES_LOTES_ibfk_1` FOREIGN KEY (`ID_paquete`) REFERENCES `PAQUETES` (`ID`),
  CONSTRAINT `PAQUETES_LOTES_ibfk_2` FOREIGN KEY (`ID_lote`) REFERENCES `LOTES` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PAQUETES_LOTES`
--

LOCK TABLES `PAQUETES_LOTES` WRITE;
/*!40000 ALTER TABLE `PAQUETES_LOTES` DISABLE KEYS */;
INSERT INTO `PAQUETES_LOTES` VALUES (1,1,'2023-09-13 23:31:38'),(2,2,'2023-09-13 23:31:38'),(3,3,'2023-09-13 23:31:38');
/*!40000 ALTER TABLE `PAQUETES_LOTES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REPARTE`
--

DROP TABLE IF EXISTS `REPARTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REPARTE` (
  `ID_paquete` int(11) NOT NULL,
  `matricula` char(7) DEFAULT NULL,
  `fecha_carga` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_descarga` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID_paquete`),
  KEY `matricula` (`matricula`),
  CONSTRAINT `REPARTE_ibfk_1` FOREIGN KEY (`ID_paquete`) REFERENCES `PAQUETES` (`ID`),
  CONSTRAINT `REPARTE_ibfk_2` FOREIGN KEY (`matricula`) REFERENCES `CAMIONETAS` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REPARTE`
--

LOCK TABLES `REPARTE` WRITE;
/*!40000 ALTER TABLE `REPARTE` DISABLE KEYS */;
INSERT INTO `REPARTE` VALUES (1,'DEF9012','2023-09-13 23:31:38',NULL),(2,'DEF9012','2023-09-13 23:31:38',NULL),(3,'DEF9012','2023-09-13 23:31:38',NULL);
/*!40000 ALTER TABLE `REPARTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TRAE`
--

DROP TABLE IF EXISTS `TRAE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TRAE` (
  `ID_paquete` int(11) NOT NULL,
  `matricula` char(7) DEFAULT NULL,
  `fecha_carga` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_descarga` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID_paquete`),
  KEY `matricula` (`matricula`),
  CONSTRAINT `TRAE_ibfk_1` FOREIGN KEY (`ID_paquete`) REFERENCES `PAQUETES` (`ID`),
  CONSTRAINT `TRAE_ibfk_2` FOREIGN KEY (`matricula`) REFERENCES `VEHICULOS` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TRAE`
--

LOCK TABLES `TRAE` WRITE;
/*!40000 ALTER TABLE `TRAE` DISABLE KEYS */;
INSERT INTO `TRAE` VALUES (1,'XYZ5678','2023-09-13 23:31:38',NULL),(2,'XYZ5678','2023-09-13 23:31:38',NULL),(3,'XYZ5678','2023-09-13 23:31:38',NULL);
/*!40000 ALTER TABLE `TRAE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TRONCALES`
--

DROP TABLE IF EXISTS `TRONCALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TRONCALES` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(32) NOT NULL,
  `baja` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TRONCALES`
--

LOCK TABLES `TRONCALES` WRITE;
/*!40000 ALTER TABLE `TRONCALES` DISABLE KEYS */;
INSERT INTO `TRONCALES` VALUES (1,'Troncal 1','\0'),(2,'Troncal 2','\0'),(3,'Troncal 3','\0'),(4,'troncal 1','\0'),(5,'troncal 2','\0');
/*!40000 ALTER TABLE `TRONCALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USUARIOS`
--

DROP TABLE IF EXISTS `USUARIOS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USUARIOS` (
  `usuario` varchar(20) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `rol` tinyint(4) NOT NULL,
  PRIMARY KEY (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USUARIOS`
--

LOCK TABLES `USUARIOS` WRITE;
/*!40000 ALTER TABLE `USUARIOS` DISABLE KEYS */;
INSERT INTO `USUARIOS` VALUES ('usuario1','contraseña1',1),('usuario2','contraseña2',2),('usuario3','contraseña3',0);
/*!40000 ALTER TABLE `USUARIOS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VEHICULOS`
--

DROP TABLE IF EXISTS `VEHICULOS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VEHICULOS` (
  `matricula` char(7) NOT NULL,
  `vol_max` int(10) unsigned NOT NULL,
  `peso_max` int(10) unsigned NOT NULL,
  `es_operativo` bit(1) NOT NULL DEFAULT b'1',
  `baja` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VEHICULOS`
--

LOCK TABLES `VEHICULOS` WRITE;
/*!40000 ALTER TABLE `VEHICULOS` DISABLE KEYS */;
INSERT INTO `VEHICULOS` VALUES ('ABC1234',100,500,'','\0'),('DEF9012',120,600,'','\0'),('XYZ5678',80,400,'','\0');
/*!40000 ALTER TABLE `VEHICULOS` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-14 19:21:07
